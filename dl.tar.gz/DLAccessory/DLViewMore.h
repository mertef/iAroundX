//
//  DLViewMore.h
//  DLAccessory
//
//  Created by Mertef on 12/27/13.
//  Copyright (c) 2013 Zhang Mertef. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLViewMore : UIView

@end

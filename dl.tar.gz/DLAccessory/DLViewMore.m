//
//  DLViewMore.m
//  DLAccessory
//
//  Created by Mertef on 12/27/13.
//  Copyright (c) 2013 Zhang Mertef. All rights reserved.
//

#import "DLViewMore.h"
#import "DLMCConfig.h"
@implementation DLViewMore

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor greenColor];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end

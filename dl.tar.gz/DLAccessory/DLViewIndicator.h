//
//  DLViewIndicator.h
//  DLAccessory
//
//  Created by Mertef on 12/25/13.
//  Copyright (c) 2013 Zhang Mertef. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLViewIndicator : UIView
@property(strong, nonatomic) NSNumber* cnumberIndicator;
@end

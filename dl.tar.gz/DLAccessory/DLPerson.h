//
//  DLPerson.h
//  DLAccessory
//
//  Created by Mertef on 12/9/13.
//  Copyright (c) 2013 Zhang Mertef. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DLPerson : NSObject
@property(strong, nonatomic) NSString* cstrName, *cstrAddress, * cstrTel;
@end
